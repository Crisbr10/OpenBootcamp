let family=['Ofelia','Yakelin','Laura','Adrian','Lili','Cristhian']
let familiS=new Set(family)

family.push('Cristhian')
console.log(familiS)
familiS.add('Javascript')
console.log(familiS)