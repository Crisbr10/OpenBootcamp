let num=10;
let count=9;
let condicion=true;
factorial: while (condicion=true){
    if(count===0){
        break factorial;
    }
    let fact=num*=count;
    console.log(fact);
    count--
}