let num=10;
let count=num-1;

while(count>0){
    let fact=num*=count
    count--;
    console.log(fact)
}