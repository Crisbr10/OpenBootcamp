let num=10;
  
for(var i=9;i>0;i--){
    var fact= num*=i;
    console.log(fact);
};