function verdadero(){
    true
}

const promesa=new Promise((resolve,reject)=>{

    if(true){
        resolve()
    }else{
        reject()
    }
});

promesa
.then(()=>{setTimeout(()=>{
    console.log('Hola soy una promesa!')
},5000)});

/*CABE RECLALCAR QUE LA FUNCION ANTERIOR ES UN SETTIMEOUT QUE SE
 EJECUTA A LOS 5 SEGUNDOS POR LO QUE EL CODIGO DESPUES DE ESTE
 COMENTARIO NO SE EJECUTARA HASTA ENTONCES*/
function* generadora(){
    let indice=0;
    while(true){
        yield(indice+=2)
    }
}
const indice= generadora();
console.log(indice.next())