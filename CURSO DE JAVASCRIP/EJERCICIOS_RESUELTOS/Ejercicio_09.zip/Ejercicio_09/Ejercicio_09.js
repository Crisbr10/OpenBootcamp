let edadUsuario=prompt('Cual es tu edad')
let edadNumber=parseInt(edadUsuario)