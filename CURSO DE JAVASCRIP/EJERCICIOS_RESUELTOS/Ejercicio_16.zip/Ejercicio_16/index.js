let nombre = "Cristhian"
let apellido = "Borges"

let Persona={
    nombre: nombre,
    apellido:apellido
}

console.log(Persona)

var fechaCaducidad = new Date(Date.now() + (3 * 60000)).toUTCString()
//sessionStorage.setItem("Persosna",JSON.stringify(Persona))
localStorage.setItem("Persona",JSON.stringify(Persona))
document.cookie=`Persona=${JSON.stringify(Persona)};expires=` + fechaCaducidad
