const element=document.querySelectorAll('.Element')
const container=document.querySelectorAll('.section')

element.forEach(element=>{
    element.addEventListener('dragstart',event=>{
        event.dataTransfer.setData('id',element.id)
    })
    console.log(element)
    element.addEventListener('dragend',()=>{
    })
})

container.forEach(section=>{
    section.addEventListener('dragover',event=>{ 
        event.preventDefault()
    })
    console.log(section)
    section.addEventListener('drop',event=>{
        const idTexto=event.dataTransfer.getData('id')
        const Parrafo =document.getElementById(idTexto)
        section.appendChild(Parrafo)
    })
})
