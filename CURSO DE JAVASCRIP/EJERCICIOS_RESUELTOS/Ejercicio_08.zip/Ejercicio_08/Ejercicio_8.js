let fecha= new Date();
console.log(fecha);

let cumpleaños= new Date(2001,11-1,10)
console.log(cumpleaños)

let hoy=cumpleaños<fecha
console.log(hoy)

//No se por que motivo me pilla el 6 cuando claramente el dia es 10
let diaNacimiento=cumpleaños.getDay()
console.log(diaNacimiento)

let mesNacimiento=cumpleaños.getMonth()
console.log(mesNacimiento)

let añoNacimiento=cumpleaños.getFullYear()
console.log(añoNacimiento)