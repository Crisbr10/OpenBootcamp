let Cristhian=
{
    nombre:'Cristhian',
    apellido:'Borges',
    edad:21,
    altura:'186 cm',
    soyDeveloper:true
}

let edad=Cristhian.edad
let amigos=[Cristhian, {nombre1:'Guido',edad:19}, {nombre2:'Jarvis', edad:20}]
console.log(amigos)

let orderAges=amigos.sort((a, b)=>{return a.edad - b.edad})
console.log(orderAges)