import { suma,multiplica } from "./controller.js";
import chalk from 'chalk'; 
const log=console.log



function calculo(result1,result2){
    return multiplica(result1,result2) 
}

log(chalk.bgRed(calculo(suma(1,2),suma(4,5))))