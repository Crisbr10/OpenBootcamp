$('button').click(()=>{
    alert("Click en el btn")
    console.log("Hola Estoy usando jQuery")
})
