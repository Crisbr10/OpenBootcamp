const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),

  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' }),
  ],
});

    const myFunction=valor=>{
        if(valor>5){
            Console.log('El valor es mayor')
        } 
        throw new Error('El valor es menor que 5')
    }


try{
    myFunction('Hola!')
}catch(e){
    logger.error('Debes introducir un numero')
}