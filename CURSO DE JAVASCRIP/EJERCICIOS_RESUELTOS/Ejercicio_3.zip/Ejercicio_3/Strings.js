let nombre="Cristhian";

let apellido="Borges";

let estudiante=`${nombre}  ${apellido}`;

let estudianteMayus=estudiante.toUpperCase();

let estudianteMinus=estudiante.toLowerCase();

let longitud=estudiante.length;

let primeraLetra=nombre[0];

let ultimaLetra=apellido[apellido.length-1];

let espacios=estudiante.trim();

let boolean=estudiante.includes(nombre);