let altura=186;

let alturaMetros=1.86;

let peso=87.5;

let alturaRedondeada=alturaMetros.toFixed(1)

let pesoredondeado=parseInt(peso)

let max=Number.MAX_VALUE+1==Number.MAX_VALUE;
console.log(max)