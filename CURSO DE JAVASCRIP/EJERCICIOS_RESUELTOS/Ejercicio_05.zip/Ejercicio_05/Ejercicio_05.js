let compra=['Pan', 'Agua', 'Jamón', 'Queso', 'Yogurt'];
compra.push('Aceite de girasol')
compra.pop()

let pelis=[
    {
     'titulo':'El Padrino',
     'director':'Francis Ford',
     'año':1927
    },
    {
     'titulo':'Parasite',
     'director':' Bong Joon-ho',
     'año':2019
    },
    {
     'titulo':'Forrest Gump',
     'director':'Robert Zemeckis',
     'año':1994
    }

]

let pelis2010=pelis.filter(obj=>obj.año>2010) 
console.log(pelis2010)

let directores=pelis.map(directores=> {return directores.director})
console.log(directores)

let titulos=pelis.map(titulos=>{return titulos.titulo})
console.log(titulos)

let titulosDirectores=pelis.map(obj=>{return obj.titulo}).concat(pelis.map(obj=>{return obj.director}))
console.log(titulosDirectores)

let titulosDirectores1=[...pelis.map(obj=>{return obj.titulo}),...(pelis.map(obj=>{return obj.director}))]
console.log(titulosDirectores1)