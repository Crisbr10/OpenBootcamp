class Persona {
    constructor() {
      let _edad;
      let _nombre;
      let _telefono;
  
      this.getEdad = function () {
        return _edad;
      };
  
      this.setEdad = function (valor) {
        if (typeof valor === 'number' && valor > 0) {
          _edad = valor;
        } else {
          console.log('Error: La edad debe ser un número positivo.');
        }
      };
  
      this.getNombre = function () {
        return _nombre;
      };
  
      this.setNombre = function (valor) {
        if (typeof valor === 'string') {
          _nombre = valor;
        } else {
          console.log('Error: El nombre debe ser una cadena de texto.');
        }
      };
  
      this.getTelefono = function () {
        return _telefono;
      };
  
      this.setTelefono = function (valor) {
        if (typeof valor === 'string') {
          _telefono = valor;
        } else {
          console.log('Error: El teléfono debe ser una cadena de texto.');
        }
      };
    }
  }
  
  // Crear un objeto persona
  let persona = new Persona();
  
  // Establecer los valores de las propiedades usando los setters
  persona.setEdad(25);
  persona.setNombre('Juan');
  persona.setTelefono('123456789');
  
  // Mostrar las propiedades usando los getters
  console.log('Edad:', persona.getEdad());
  console.log('Nombre:', persona.getNombre());
  console.log('Teléfono:', persona.getTelefono());
  