// Clase Persona
class Persona {
    constructor(edad, nombre, telefono) {
      this.edad = edad;
      this.nombre = nombre;
      this.telefono = telefono;
    }
  }
  
  // Clase Cliente que hereda de Persona
  class Cliente extends Persona {
    constructor(edad, nombre, telefono, credito) {
      super(edad, nombre, telefono);
      this.credito = credito;
    }
  }
  
  // Clase Trabajador que hereda de Persona
  class Trabajador extends Persona {
    constructor(edad, nombre, telefono, salario) {
      super(edad, nombre, telefono);
      this.salario = salario;
    }
  }
  
  // Crear un objeto de la clase Cliente y mostrar sus propiedades
  let cliente = new Cliente(30, 'Juan', '123456789', 1000);
  console.log('Cliente:');
  console.log('Edad:', cliente.edad);
  console.log('Nombre:', cliente.nombre);
  console.log('Teléfono:', cliente.telefono);
  console.log('Crédito:', cliente.credito);
  
  // Crear un objeto de la clase Trabajador y mostrar sus propiedades
  let trabajador = new Trabajador(35, 'María', '987654321', 2000);
  console.log('Trabajador:');
  console.log('Edad:', trabajador.edad);
  console.log('Nombre:', trabajador.nombre);
  console.log('Teléfono:', trabajador.telefono);
  console.log('Salario:', trabajador.salario);
  