// Definir la función de suma con tres parámetros numéricos
function sumaNumeros(num1, num2, num3) {
  return num1 + num2 + num3;
}

// Llamar a la función y asignar valores a los parámetros
let resultado = sumaNumeros(2, 4, 6);
console.log(resultado); // Imprimirá 12 en la consola

// Definir la clase Coche
class Coche {
  constructor() {
    this.numeroPuertas = 0;
  }

  // Función para incrementar el número de puertas
  incrementarPuertas() {
    this.numeroPuertas++;
  }
}

// Crear un objeto de la clase Coche
let miCoche = new Coche();

// Añadir una puerta al coche
miCoche.incrementarPuertas();

// Mostrar el número de puertas que tiene el objeto
console.log(miCoche.numeroPuertas); // Imprimirá 1 en la consola
